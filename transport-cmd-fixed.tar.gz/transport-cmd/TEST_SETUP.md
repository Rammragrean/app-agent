# ✅ Setup Verification Checklist

## Before Running npm run dev

### 1. Check Files Exist
```bash
ls -la src/app/page.tsx
ls -la src/app/api/notion/route.ts
ls -la src/lib/notion.ts
ls -la .env.local
```

### 2. Verify Dependencies
```bash
cat package.json | grep "@notionhq/client"
cat package.json | grep "recharts"
```

### 3. Check .env.local
```bash
cat .env.local
```

Expected: Empty or commented out = Development Mode ✅

---

## After Running npm run dev

### Test 1: Homepage Loads
- URL: http://localhost:3000
- Expected: Dashboard with yellow banner
- Contains: Stats cards, Team Performance, Task Grid

### Test 2: API Works
- URL: http://localhost:3000/api/notion?type=tasks
- Expected: JSON with 10 tasks
- Contains: `{"tasks": [...]}`

### Test 3: Team Page Works
- URL: http://localhost:3000/team
- Expected: Line chart + table
- Contains: Performance trends

---

## Common Issues & Fixes

| Issue | Fix |
|-------|-----|
| 404 on homepage | `rm -rf .next && npm run dev` |
| API 500 error | Check console logs, verify mock data loaded |
| Blank page | Clear browser cache, hard refresh (Ctrl+Shift+R) |
| Module not found | `rm -rf node_modules && npm install` |

---

## Expected Console Output

```
⚠️ Development Mode: Using mock data (Notion credentials not configured)
📊 Returning mock tasks (10 items)
✓ Ready in 2.5s
○ Compiling /api/notion/route ...
✓ Compiled /api/notion/route in 1.2s
```

---

## Success Criteria ✅

- [ ] Homepage loads without errors
- [ ] Yellow "Development Mode" banner visible
- [ ] Stats show: Total Tasks = 10
- [ ] Team Performance shows 7 members
- [ ] Category Distribution shows all 4 categories
- [ ] Task cards display correctly
- [ ] /team page loads with chart
- [ ] No console errors (except mock data warning)

If all boxes checked = Setup successful! 🎉
