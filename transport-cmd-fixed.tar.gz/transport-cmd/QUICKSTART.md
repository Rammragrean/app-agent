# 🚀 Quick Start Guide

## ⚡ เริ่มใช้งานแบบเร็ว (Windows)

### วิธี 1: ใช้ Fix Script (แนะนำ)
```cmd
cd C:\Users\LENOVO\Desktop\Work\Agent\transport-cmd
fix.bat
```

Fix script จะ:
1. ลบไฟล์เก่า (.next, node_modules)
2. Install dependencies ใหม่
3. ตรวจสอบ .env.local
4. รัน dev server

---

## 📋 เริ่มใช้งานแบบปกติ

### 1️⃣ Install Dependencies
```bash
cd transport-cmd
npm install
```

**หมายเหตุ**: ถ้าเจอ error **"Cannot find module 'autoprefixer'"**
```bash
npm install autoprefixer --save-dev
```

### 2️⃣ Start Development Server
```bash
npm run dev
```

### 3️⃣ Open Browser
เปิด http://localhost:3000

---

## 💡 What You'll See

เมื่อเปิดครั้งแรก จะเห็น:

✅ **Yellow Banner** = Development Mode (ใช้ Mock Data)  
✅ **Dashboard** พร้อม Stats Cards  
✅ **10 งานตัวอย่าง** (Inbound, Outbound, Internal, Project)  
✅ **7 สมาชิกทีม** (2 Supervisors + 5 Staff)  

---

## 🔗 Connect Notion (Optional)

เมื่อพร้อมเชื่อม Notion:

### Step 1: สร้าง Integration
1. ไปที่ https://www.notion.so/my-integrations
2. กด **"New integration"**
3. ตั้งชื่อ เช่น "Transport CMD"
4. Copy **Internal Integration Token**

### Step 2: สร้าง Database
สร้าง Database ใน Notion ด้วย properties:

| Property | Type | Options |
|----------|------|---------|
| Name | Title | - |
| Status | Select | Done, In Progress, Pending, Blocked |
| Assignee | Person | - |
| Priority | Select | High, Medium, Low |
| Due Date | Date | - |
| Category | Select | **Inbound, Outbound, Internal, Project** |

### Step 3: Share Database
1. เปิด Database
2. กด **"•••"** (มุมขวาบน)
3. เลือก **"Add connections"**
4. เลือก Integration ที่สร้างไว้

### Step 4: Get Database ID
Copy Database ID จาก URL:
```
https://notion.so/workspace/DATABASE_ID?v=...
                          ^^^^^^^^^^^^
```

### Step 5: Config .env.local
```bash
NOTION_API_KEY=secret_xxxxxxxxxxxxx
NOTION_DATABASE_ID=xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Step 6: Restart Server
```bash
# Stop server (Ctrl+C)
npm run dev
```

Yellow banner จะหายไป = เชื่อม Notion สำเร็จ! 🎉

---

## 🐛 เจอปัญหา?

### หน้าขึ้น 404
```bash
rm -rf .next
npm run dev
```

### API Error
ตรวจสอบ `.env.local`:
- ใส่ Token ถูกต้องหรือไม่?
- Database ID ถูกต้องหรือไม่?
- Share Database กับ Integration แล้วหรือยัง?

### ไม่มี Notion ก็ได้
ปล่อย `.env.local` เป็นค่าเดิม → ระบบใช้ Mock Data ต่อไป ✅

---

## 📚 Next Steps

- เปิด `/team` ดู Performance Trends
- ลอง Filter งานตาม Category
- ดู Team Member Cards
- Customize ตาม requirement

Happy coding! 🚀
